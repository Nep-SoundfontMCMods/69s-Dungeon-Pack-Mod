# 69's dungeon pack mod
 A Mapmaking mod for minecraft adding some unbreakable utilities
# About
 This mod adds three items at the moment: A random loot crate spawner, a set of time trial tools and some sound triggers, configureable by resource pack!
# Loot Containers:
 These contain items and come in 5 types: 
 -Wood: stores 3 items
 -Metal: stores 5 items
 -Tank: Stores 2 items and 50 buckets of a fluid (the fluid part is NYI at the moment)
 -Battery: stores 0 items and 0 buckets of liquid, but can output a lot of energy
 -Alien container: rarest container, Stores 9 items, 5 fluid buckets and some energy
 -Randomizer: block that immediately replaces itself with a random container
 All the containers have their own loot tables preconfigured, but they're not included in the mod itself.
 the IDs need to be added to each world in (save)/data/loot_tables/dungeonsixnine/(paste loot tables here)
 you can make custom loot tables at https://minecraft.tools 
 loot tables are: wood, metal, tank, battery and alien
# 